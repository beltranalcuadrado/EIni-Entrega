package test;

import domain.*;
import org.junit.Test;
import static org.junit.Assert.*;

import org.junit.Before;

public class PlayerTest{
    private Player jugador;
    @Before
    public void setUp(){
        jugador = new Player(100);
    }
    @Test
    public void deberiaSaltarYVolverAlSuelo(){
        jugador.jump();
        jugador.update();
        assertTrue(jugador.getY() < 450); //Está en el aire

        for (int i = 1; i <= 100; i++){
            jugador.update();
        }
        assertEquals(450, jugador.getY());
        assertTrue(jugador.isOnGround());
    }  

    @Test
    public void noDeberiaSaltarEnElAire(){
        jugador.jump();
        for (int i = 1; i <= 25; i++){
            jugador.update();
        }
        int y = jugador.getY();
        jugador.jump(); //Este jump no deberia funcionar, aun esta en el aire
        jugador.update();
        assertTrue(y < jugador.getY());
    }

    @Test
    public void deberiaPerderVidaAlRecibirDano(){
        jugador.takeDamage(30);
        int life = jugador.getLife();
        assertEquals(70, life);
    }
    @Test
    public void deberiaQuedarAturdidoSinVida(){
        jugador.takeDamage(100);
        assertEquals(0, jugador.getLife());
        assertTrue(jugador.isStunned());

        for (int  i = 1; i <= 180; i++){
            jugador.update();
        }

        assertFalse(jugador.isStunned());
        assertEquals(100, jugador.getLife());
    }

    @Test
    public void deberiaActivarAuraConBarraLlena(){
        jugador.addPower(Player.POWER_BAR_FULL);
        jugador.activatePower();
        assertTrue(jugador.hasAura());
        assertEquals(0, jugador.getPowerBar());
    }
    @Test
    public void noDeberiaActivarAuraSinBarraLlena(){
        jugador.activatePower();
        assertFalse(jugador.hasAura()); //Verifica que el poder no se activa hasta que la barra esté llena
    }

    @Test
    public void noDeberiaSaltarElectrocutado(){
        jugador.applyEffect(new Electrocuted(), 180);
        jugador.jump();
        jugador.update();
        assertEquals(450, jugador.getY());
    }

    @Test
    public void deberiaQuitarseElEfectoAlTerminar(){
        jugador.applyEffect(new Unconscious(), 180);

        for (int i = 1; i <= 200; i++){
            jugador.update();
        }

        jugador.jump();
        jugador.update();
        assertTrue(jugador.getY() < 450); //Verificar que si salto
    }
}