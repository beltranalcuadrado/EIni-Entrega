package presentation;

import javax.swing.*;
import java.awt.*;

public class PantallaConfiguracion extends PanelFondo {
    private JComboBox<String> modalidad  = new JComboBox<>(new String[]{"Jugador vs Jugador", "Jugador vs Máquina"});
    private JComboBox<String> perfil     = new JComboBox<>(new String[]{"Torpe", "Ofensiva", "Defensiva", "Experta"});
    private JComboBox<String> resolucion = new JComboBox<>(new String[]{"800x600", "1024x768", "1280x720"});
    private JComboBox<String> tipo       = new JComboBox<>(new String[]{"Por goles", "Por tiempo"});
    private JSpinner limite              = new JSpinner(new SpinnerNumberModel(3, 1, 99, 1));

    private JLabel etiquetaPerfil = crearEtiqueta("Perfil de la máquina:");
    private JLabel etiquetaLimite = crearEtiqueta("Goles para ganar:");

    public PantallaConfiguracion(Runnable alSiguiente) {
        setLayout(new GridBagLayout());                 

        JPanel formulario = new JPanel(new GridLayout(0, 2, 10, 12));
        formulario.setOpaque(false);                 

        formulario.add(crearEtiqueta("Modalidad:"));          formulario.add(modalidad);
        formulario.add(etiquetaPerfil);                       formulario.add(perfil);
        formulario.add(crearEtiqueta("Resolución:"));         formulario.add(resolucion);
        formulario.add(crearEtiqueta("Tipo de partido:"));    formulario.add(tipo);
        formulario.add(etiquetaLimite);                       formulario.add(limite);

        JButton siguiente = new JButton("Siguiente");
        siguiente.addActionListener(e -> alSiguiente.run());
        formulario.add(new JLabel());                      
        formulario.add(siguiente);

        add(formulario);


        modalidad.addActionListener(e -> actualizarPerfil());
        tipo.addActionListener(e -> actualizarLimite());
        actualizarPerfil();
        actualizarLimite();
    }

    private JLabel crearEtiqueta(String texto) {
        JLabel l = new JLabel(texto);
        l.setForeground(Color.WHITE);                   
        return l;
    }

    private void actualizarPerfil() {
        boolean vsMaquina = esContraMaquina();
        etiquetaPerfil.setVisible(vsMaquina);
        perfil.setVisible(vsMaquina);
    }

    private void actualizarLimite() {
        if (tipo.getSelectedIndex() == 1) {
            etiquetaLimite.setText("Minutos de duración:");
        } else {
            etiquetaLimite.setText("Goles para ganar:");
        }
    }

    public boolean esContraMaquina() { 
        return modalidad.getSelectedIndex() == 1; 
    }
    public String getPerfil()        { 
        return (String) perfil.getSelectedItem(); 
    }
    public String getResolucion()    { 
        return (String) resolucion.getSelectedItem(); 
    }  
    public String getTipo()          { 
        return tipo.getSelectedIndex() == 1 ? "TIME" : "GOALS"; 
    }
    public int getLimite()           { 
        return (Integer) limite.getValue(); 
    }
}