package presentation;

import javax.swing.*;
import java.awt.*;

public class PantallaPersonajes extends PanelFondo {
    private static final String[] PERSONAJES = {"Corea del Sur", "Camerún", "Nigeria", "Estados Unidos"};

    private JComboBox<String> personaje1 = new JComboBox<>(PERSONAJES);
    private JComboBox<String> personaje2 = new JComboBox<>(PERSONAJES);

    public PantallaPersonajes(Runnable alSiguiente) {
        setLayout(new GridBagLayout());                

        JPanel formulario = new JPanel(new GridLayout(0, 2, 10, 12));
        formulario.setOpaque(false);                    

        personaje2.setSelectedIndex(1);                 

        formulario.add(crearEtiqueta("Personaje del Jugador 1:"));  formulario.add(personaje1);
        formulario.add(crearEtiqueta("Personaje del Jugador 2:"));  formulario.add(personaje2);

        JButton siguiente = new JButton("Listo");
        siguiente.addActionListener(e -> alSiguiente.run());
        formulario.add(new JLabel());                    
        formulario.add(siguiente);

        add(formulario);
    }

    private JLabel crearEtiqueta(String texto) {
        JLabel l = new JLabel(texto);
        l.setForeground(Color.WHITE);                    
        return l;
    }

    public String getPersonaje1() { 
        return (String) personaje1.getSelectedItem(); 
    }
    public String getPersonaje2() { 
        return (String) personaje2.getSelectedItem(); 
    }
}