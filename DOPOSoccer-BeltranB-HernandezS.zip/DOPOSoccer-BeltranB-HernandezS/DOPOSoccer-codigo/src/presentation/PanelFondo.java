package presentation;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;

public class PanelFondo extends JPanel {
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
                            RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        BufferedImage fondo = ResourceManager.getSprite("fondo");
        if (fondo != null) {
            g2.drawImage(fondo, 0, 0, getWidth(), getHeight(), null);
        }
        g2.setColor(new Color(0, 0, 0, 140));          
        g2.fillRect(0, 0, getWidth(), getHeight());
    }
}
