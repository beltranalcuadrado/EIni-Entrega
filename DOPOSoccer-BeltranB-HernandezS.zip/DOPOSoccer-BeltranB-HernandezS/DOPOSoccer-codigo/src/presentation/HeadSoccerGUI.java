package presentation;
import java.io.*;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;

import java.awt.*;
import java.awt.event.*;
import domain.*; 
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.HashMap;
import java.util.Map;

import presentation.*;

public class HeadSoccerGUI extends JFrame {


    private HeadSoccer game;
    private boolean moviendoIzquierdaJ1 = false;
    private boolean moviendoDerechaJ1 = false;
    private boolean moviendoIzquierdaJ2 = false;
    private boolean moviendoDerechaJ2 = false;
    private JMenuItem nuevo;
	private JMenuItem abrir;
	private JMenuItem salvar;
	private JMenuItem salir;
    
    private boolean contraMaquina;

    // Nombre del personaje -> prefijo de sus imágenes en sprites/personajes
    private static final Map<String, String> CLAVES = new HashMap<>();
    static {
        CLAVES.put("Corea del Sur", "corea");
        CLAVES.put("Camerún", "camerun");
        CLAVES.put("Nigeria", "nigeria");
        CLAVES.put("Estados Unidos", "usa");
    }


    private Timer timer;
    private PanelTablero tableroGUI;

    private String personaje1;
    private String personaje2;

    private CardLayout cardLayout = new CardLayout();
    private JPanel contenedor = new JPanel(cardLayout);
    private PantallaInicio pantallaInicio;
    private PantallaConfiguracion pantallaConfig;
    private PantallaPersonajes pantallaPersonajes;

    public HeadSoccerGUI() {
        ResourceManager.inicializar();
        setSize(800, 600);
        prepareView();
        prepareController();
    }

    private void prepareView() { 
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        prepareViewMenu();

        pantallaInicio = new PantallaInicio(
            () -> cardLayout.show(contenedor, "config"),
            () -> open(),
            () -> exit());
        pantallaConfig = new PantallaConfiguracion(() -> cardLayout.show(contenedor, "personajes"));
        pantallaPersonajes = new PantallaPersonajes(() -> iniciarPartida());

        tableroGUI = new PanelTablero();
        tableroGUI.setBackground(Color.DARK_GRAY);

        contenedor.add(pantallaInicio, "inicio");
        contenedor.add(pantallaConfig, "config");
        contenedor.add(pantallaPersonajes, "personajes");
        contenedor.add(tableroGUI, "juego");
        add(contenedor, BorderLayout.CENTER);

        cardLayout.show(contenedor, "inicio");
        mostrarMenu(false);
    }

    // La barra Archivo solo sirve mientras hay una partida en curso
    private void mostrarMenu(boolean visible) {
        getJMenuBar().setVisible(visible);
        revalidate();
    }

    private void iniciarPartida() {
        try {
            personaje1 = pantallaPersonajes.getPersonaje1();
            personaje2 = pantallaPersonajes.getPersonaje2();
            contraMaquina = pantallaConfig.esContraMaquina();

            game = new HeadSoccer(pantallaConfig.getTipo(), pantallaConfig.getLimite(), personaje1, personaje2);
            if (contraMaquina) {
                game.setMachine(pantallaConfig.getPerfil());
            }

            String[] partes = pantallaConfig.getResolucion().split("x");
            setSize(Integer.parseInt(partes[0]), Integer.parseInt(partes[1]));
            setLocationRelativeTo(null);

            moviendoIzquierdaJ1 = false;
            moviendoDerechaJ1 = false;
            moviendoIzquierdaJ2 = false;
            moviendoDerechaJ2 = false;

            cardLayout.show(contenedor, "juego");
            mostrarMenu(true);
            iniciarJuego();
            SwingUtilities.invokeLater(() -> requestFocusInWindow()); 
        } catch (POOBSoccerException e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }

    private void prepareController() {
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);

		addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e){
				exit();
			}
		});
		prepareControllerMenu();
            addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (game == null){
                    return;
                }
                if (e.getKeyCode() == KeyEvent.VK_A) {
                    moviendoIzquierdaJ1 = true;
                }
                if (e.getKeyCode() == KeyEvent.VK_D) {
                    moviendoDerechaJ1 = true;
                }
                if (e.getKeyCode() == KeyEvent.VK_W) {
                    game.jump(1);
                }
                if (e.getKeyCode() == KeyEvent.VK_S) {
                    game.kick(1);
                }
                if (!contraMaquina){
                    if (e.getKeyCode() == KeyEvent.VK_LEFT) {
                        moviendoIzquierdaJ2 = true;
                    }
                    if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
                        moviendoDerechaJ2 = true;
                    }
                    if (e.getKeyCode() == KeyEvent.VK_UP) {
                        game.jump(2);
                    }
                    if (e.getKeyCode() == KeyEvent.VK_DOWN) {
                        game.kick(2);
                    }
                    if (e.getKeyCode() == KeyEvent.VK_ENTER){ //Activar el poder pal jugador 2
                        game.activatePower(2);
                    }
                }
                
                if (e.getKeyCode() == KeyEvent.VK_P){
                    if (game.isPaused()){
                        game.resume();
                    }
                    else{
                        game.pause();
                    }
                }
                if (e.getKeyCode() == KeyEvent.VK_ESCAPE){
                    game.end();
                }

                if (e.getKeyCode() == KeyEvent.VK_E){ //Activar el poder del jugador 1
                    game.activatePower(1);
                }
            }

            @Override
            public void keyReleased(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_A) {
                    moviendoIzquierdaJ1 = false;
                }
                if (e.getKeyCode() == KeyEvent.VK_D) {
                    moviendoDerechaJ1 = false;
                }

                if (e.getKeyCode() == KeyEvent.VK_LEFT) {
                    moviendoIzquierdaJ2 = false;
                }
                if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
                    moviendoDerechaJ2 = false;
                }
            }  
        });
        setFocusable(true);
        requestFocusInWindow();
            }

    	private void exit(){
		int n = JOptionPane.showConfirmDialog(this, "¿Seguro que desea salir?", "Salir", JOptionPane.YES_NO_OPTION);
		
		if (n == JOptionPane.YES_OPTION){
			System.exit(0);
		}
	}

	private void prepareViewMenu(){
		JMenuBar barra = new JMenuBar();
		JMenu archivo = new JMenu("Archivo");
		
		nuevo = new JMenuItem("Nuevo");
		abrir = new JMenuItem("Abrir");
		salvar = new JMenuItem("Salvar");
		salir = new JMenuItem("Salir");

		archivo.add(nuevo);
		archivo.addSeparator();
		archivo.add(abrir);
		archivo.add(salvar);
		archivo.addSeparator();
		archivo.add(salir);
		
		barra.add(archivo);

		setJMenuBar(barra);
	}

    private void prepareControllerMenu(){
		salir.addActionListener (new ActionListener(){
			public void actionPerformed(ActionEvent e){
				exit();
			}
		});

		abrir.addActionListener (new ActionListener(){
			public void actionPerformed(ActionEvent e){
				open();
			}
		});

		salvar.addActionListener (new ActionListener(){
			public void actionPerformed(ActionEvent e){
				save();
			}
		});
        nuevo.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                nuevo();
            }
        });
    }

    private void nuevo() {
        if (timer != null) {
            timer.stop();
        }
        game = null;
        cardLayout.show(contenedor, "inicio");
        mostrarMenu(false);

    }


    private void open() {
        boolean habiaPartida = (game != null);
        boolean estabaPausado = habiaPartida && game.isPaused();
        if (habiaPartida) game.pause();

        boolean cargada = false;
        JFileChooser fc = new JFileChooser();
        fc.setFileFilter(new FileNameExtensionFilter("Partida HeadSoccer (*.soccer)", "soccer"));
        if (fc.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            try {
                game = HeadSoccer.open(fc.getSelectedFile());
                contraMaquina = game.hasMachine();
                game.resume();
                personaje1 = game.getCharacterName(1);  
                personaje2 = game.getCharacterName(2);
                moviendoIzquierdaJ1 = false;
                moviendoDerechaJ1 = false;
                moviendoIzquierdaJ2 = false;
                moviendoDerechaJ2 = false;
                cardLayout.show(contenedor, "juego");
                mostrarMenu(true);
                iniciarJuego();
                cargada = true;
            } catch (POOBSoccerException e) {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
        }

        if (!cargada && habiaPartida && !estabaPausado) game.resume();
        SwingUtilities.invokeLater(() -> requestFocusInWindow());
    }

    private void save() {
        if (game == null) {
            JOptionPane.showMessageDialog(this, "No hay una partida para guardar");
            return;
        }
        boolean estabaPausado = game.isPaused();
        game.pause();

        JFileChooser fc = new JFileChooser();
        fc.setFileFilter(new FileNameExtensionFilter("Partida HeadSoccer (*.soccer)", "soccer"));
        if (fc.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            File f = fc.getSelectedFile();
            if (!f.getName().endsWith(".soccer")) {
                f = new File(f.getPath() + ".soccer");
            }
            try {
                game.save(f);
                JOptionPane.showMessageDialog(this, "Partida guardada");
            } catch (POOBSoccerException e) {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
        }

        if (!estabaPausado) game.resume();
        requestFocusInWindow();   // el diálogo le quita el foco al teclado
    }

    private void iniciarJuego() {
        if (timer != null){
            timer.stop();
        }
        timer = new Timer(16, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (moviendoIzquierdaJ1) {
                    game.moveLeft(1); 
                }
                else if (moviendoDerechaJ1) {
                    game.moveRight(1);
                }
                else {
                    game.stop(1); 
                }
                if (!contraMaquina){
                    if (moviendoIzquierdaJ2) {
                        game.moveLeft(2); 
                    }
                    else if (moviendoDerechaJ2) {
                        game.moveRight(2);
                    }
                    else {
                        game.stop(2); 
                    }
                }
                game.update();
                tableroGUI.repaint();
                if (game.isFinished()){
                    timer.stop();
                    mostrarGanador();
                }
            }
        });
        timer.start();
    }

    private void mostrarGanador(){
        String mensaje;
        int ganador = game.getWinner();

        if (ganador == 1){
            mensaje = "¡Ganó el Jugador 1!\n\nJugador 1: +100 puntos\nJugador 2: +25 puntos";
        }
        else if (ganador == 2){
            mensaje = "¡Ganó el Jugador 2!\n\nJugador 2: +100 puntos\nJugador 1: +25 puntos";
        }
        else{
            mensaje = "Empate\n\nNo hay ganador";
        }
        JOptionPane.showMessageDialog(this, mensaje, "Fin del partido", JOptionPane.INFORMATION_MESSAGE);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new HeadSoccerGUI().setVisible(true);
            }
        });
    }

private class PanelTablero extends JPanel {
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);          
            if (game == null){
                return; // si el partido no se creó, no hay nada que dibujar
            }

            // Cancha: fondo, piso y arcos (con sprites o, si no cargan, con figuras)
            dibujarFondo(g);
            dibujarPiso(g);
            dibujarArco(g, "arco_atras", false);
            dibujarArco(g, "arco_atras", true);

            // Jugadores (aura detrás, sprite, y gris encima si está aturdido)
            dibujarJugadorCompleto(g, 1, CLAVES.get(game.getCharacterName(1)), Color.BLUE, true);
            dibujarJugadorCompleto(g, 2, CLAVES.get(game.getCharacterName(2)), Color.RED, false);

            // Balón
            BufferedImage imgBalon = ResourceManager.getSprite("ball");
            int ball = game.getBallSize();
            if (imgBalon != null){
                dibujarSprite(g, imgBalon, game.getBallX(), game.getBallY(), ball, false);
            }
            else{
                g.setColor(Color.WHITE);
                g.fillOval(sx(game.getBallX() - ball / 2), sy(game.getBallY() - ball), sx(ball), sy(ball));
            }

            //Visualizacion del nombre del pais de cada jugador
            g.setColor(Color.WHITE);
            g.setFont(new Font("Arial", Font.BOLD, 14));
            g.drawString(game.getCharacterName(1), 20, 15);
            g.drawString(game.getCharacterName(2), getWidth() - 220, 15);

            g.setColor(Color.WHITE);
            g.setFont(new Font("Arial", Font.BOLD, 28));
            g.drawString(game.getGoals(1) + " - " + game.getGoals(2), getWidth() / 2 - 30, 40);

            int time = game.getRemainingTime();
            if (time != -1) {
                String clock = (time / 60) + ":" + String.format("%02d", time % 60);
                g.drawString(clock, getWidth() / 2 - 30, 75);
            }

            //Barra de vida para cada jugador
            int vida1 = game.getLife(1);
            int vidaMax1 = game.getMaxLife(1);
            g.setColor(Color.DARK_GRAY);
            g.fillRect(20, 20, 200, 15);
            g.setColor(Color.GREEN);
            g.fillRect(20, 20, 200 * vida1/ vidaMax1, 15);

            int vida2 = game.getLife(2);
            int vidaMax2 = game.getMaxLife(2);
            g.setColor(Color.DARK_GRAY);
            g.fillRect(getWidth() - 220, 20, 200, 15);
            g.setColor(Color.GREEN);
            g.fillRect(getWidth() - 220, 20, 200 * vida2/ vidaMax2, 15);

            //Barra de poder para cada jugador
            g.setColor(Color.DARK_GRAY);
            g.fillRect(20, 40, 200, 10);
            g.setColor(Color.YELLOW);
            g.fillRect(20, 40, 200 * game.getPowerBar(1) / game.getPowerBarFull(), 10);

            g.setColor(Color.DARK_GRAY);
            g.fillRect(getWidth() - 220, 40, 200, 10);
            g.setColor(Color.YELLOW);
            g.fillRect(getWidth() - 220, 40, 200 * game.getPowerBar(2) / game.getPowerBarFull(), 10);
        }

        // Dibuja un jugador con todo lo que le corresponde: aura, sprite (o cuadro de color) y aturdimiento
        private void dibujarJugadorCompleto(Graphics g, int n, String pais, Color colorRespaldo, boolean espejo){
            int size = game.getPlayerSize();
            int x = game.getPlayerX(n);
            int y = game.getPlayerY(n);

            //Aura (va primero para que quede detrás del jugador)
            if (game.hasAura(n)){
                g.setColor(Color.YELLOW);
                g.fillOval(sx(x - size / 2 - 10), sy(y - size - 10), sx(size + 20), sy(size + 20));
            }

            if (pais != null && ResourceManager.getSprite(pais, "cabeza") != null){
                dibujarJugador(g, pais, x, y, espejo);
            }
            else{
                g.setColor(colorRespaldo);
                g.fillRect(sx(x - size / 2), sy(y - size), sx(size), sy(size));
            }

            //Aturdido: capa gris semitransparente encima del jugador
            if (game.isStunned(n)){
                g.setColor(new Color(128, 128, 128, 170));
                g.fillRect(sx(x - size / 2), sy(y - size), sx(size), sy(size));
            }
        }

        // ----- Métodos de dibujo con sprites (hechos por Santiago) -----

        private void dibujarSprite(Graphics g, BufferedImage img, int cx, int base, int ancho, boolean espejo) {
            if (img == null) return;
            int alto = ancho * img.getHeight() / img.getWidth();
            int w = sx(ancho);
            int h = sx(alto);
            int x = sx(cx) - w / 2;
            int y = sy(base) - h;
            if (espejo) {
                g.drawImage(img, x + w, y, -w, h, null);
            } else {
                g.drawImage(img, x, y, w, h, null);
            }
        }

        private void dibujarJugador(Graphics g, String pais, int x, int y, boolean espejo) {
            int S = game.getPlayerSize();
            dibujarSprite(g, ResourceManager.getSprite(pais, "piernas"), x, y,            S * 45 / 100, espejo);
            dibujarSprite(g, ResourceManager.getSprite(pais, "cuerpo"),  x, y - S * 20 / 100, S * 55 / 100, espejo);
            dibujarSprite(g, ResourceManager.getSprite(pais, "cabeza"),  x, y - S * 40 / 100, S * 80 / 100, espejo);
            dibujarSprite(g, ResourceManager.getSprite(pais, "sombrero"), x, y - S * 70 / 100, S * 90 / 100, espejo);
        }

        private void dibujarFondo(Graphics g) {
            BufferedImage fondo = ResourceManager.getSprite("fondo");
            if (fondo != null) {
                g.drawImage(fondo, 0, 0, getWidth(), getHeight(), null);   // se estira para llenar todo
            } else {
                g.setColor(new Color(40, 140, 40));
                g.fillRect(0, 0, getWidth(), getHeight());
            }
        }

        private void dibujarPiso(Graphics g) {
            BufferedImage piso = ResourceManager.getSprite("piso");
            int y = sy(450);
            int alto = getHeight() - y;
            if (piso != null) {
                int ancho = Math.max(1, piso.getWidth() * alto / piso.getHeight());
                for (int x = 0; x < getWidth(); x += ancho) {               // se repite (mosaico) a lo ancho
                    g.drawImage(piso, x, y, ancho, alto, null);
                }
            } else {
                g.setColor(new Color(110, 70, 30));
                g.fillRect(0, y, getWidth(), alto);
            }
        }

        private void dibujarArco(Graphics g, String parte, boolean derecho) {
            BufferedImage arco = ResourceManager.getSprite(parte);
            int x = derecho ? sx(950) : sx(0);
            int y = sy(300);
            int w = sx(50);
            int h = sy(150);
            if (arco == null) {
                g.setColor(Color.LIGHT_GRAY);
                g.fillRect(x, y, w, h);
            } else if (derecho) {
                g.drawImage(arco, x, y, w, h, null);
            } else {
                g.drawImage(arco, x + w, y, -w, h, null);
            }
        }

        private int sx(int x){
            return (int) (x * getWidth() / (double) game.getPitchWidth());
        }

        private int sy(int y){
            return (int) (y * getHeight() / (double) game.getPitchHeight());
        }
    }
}