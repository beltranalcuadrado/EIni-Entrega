package presentation;

import javax.swing.*;
import java.awt.*;

public class PantallaInicio extends PanelFondo {

    public PantallaInicio(Runnable alJugar, Runnable alAbrir, Runnable alSalir) {
        setLayout(new GridBagLayout());               

        JPanel contenido = new JPanel();
        contenido.setLayout(new BoxLayout(contenido, BoxLayout.Y_AXIS));   
        contenido.setOpaque(false);                        

        JLabel titulo = new JLabel("HEAD SOCCER");
        titulo.setForeground(Color.YELLOW);
        titulo.setFont(ResourceManager.fuenteArcade.deriveFont(48f));
        titulo.setAlignmentX(Component.CENTER_ALIGNMENT);

        JButton jugar = crearBoton("Jugar", alJugar);
        JButton abrir = crearBoton("Abrir partida", alAbrir);
        JButton salir = crearBoton("Salir", alSalir);

        contenido.add(titulo);
        contenido.add(Box.createVerticalStrut(40));     
        contenido.add(jugar);
        contenido.add(Box.createVerticalStrut(15));
        contenido.add(abrir);
        contenido.add(Box.createVerticalStrut(15));
        contenido.add(salir);

        add(contenido);
    }

    private JButton crearBoton(String texto, Runnable accion) {
        JButton b = new JButton(texto);
        b.setAlignmentX(Component.CENTER_ALIGNMENT);
        b.setMaximumSize(new Dimension(220, 40));         
        b.addActionListener(e -> accion.run());
        return b;
    }
}