package presentation;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.awt.Font;
import java.io.File;
import java.util.HashMap;

public class ResourceManager {
    private static final String[] PAISES = {"corea", "camerun", "nigeria", "usa"};
    private static final String[] PARTES = {"cuerpo", "cabeza"};

    private static HashMap<String, BufferedImage> sprites = new HashMap<>();
    public static Font fuenteArcade;

    public static void inicializar() {
        cargar("ball", "sprites/personajes/balon.png");
        cargar("fondo", "sprites/fondo/fondo.png");
        cargar("piso", "sprites/fondo/piso.png");
        cargar("arco_atras",  "sprites/fondo/arco2.png");
        cargar("arco_frente", "sprites/fondo/arco1.png");
        for (String pais : PAISES)
            for (String parte : PARTES)
                cargar(pais + "_" + parte, "sprites/personajes/" + pais + "_" + parte + ".png");
        try {
            fuenteArcade = Font.createFont(Font.TRUETYPE_FONT, new File("fonts/Marker Felt.ttf")).deriveFont(24f);
        } catch (Exception e) {
            fuenteArcade = new Font("Arial", Font.BOLD, 24);
        }
    }

    private static void cargar(String clave, String ruta) {
        try {
            sprites.put(clave, ImageIO.read(new File(ruta)));
        } catch (Exception e) {
            System.err.println("No se pudo cargar " + ruta);
        }
    }

    public static BufferedImage getSprite(String nombre) {
        return sprites.get(nombre);
    }

    public static BufferedImage getSprite(String pais, String parte) {
        return sprites.get(pais + "_" + parte);
    }
}
