package domain;
import java.io.*;
public class POOBSoccerException extends Exception{
    public static final String INVALID_MATCH_TYPE = "El tipo de partido no es válido";
    public static final String INVALID_LIMIT = "El límite debe ser mayor que 0";
    public static final String INVALID_CHARACTER = "El personaje no es válido";
    public static final String INVALID_PROFILE = "El perfil de máquina no es válido";
    public static final String SAVE_ERROR = "No se pudo guardar la partida, verifique que este guardando un .soccer";
public static final String OPEN_ERROR = "No se pudo abrir la partida. Verifique que sea un archivo válido";

    public POOBSoccerException(String message){
        super(message);
    }
}
