package domain;
import java.io.*;
public abstract class Character implements java.io.Serializable{
    private static final long serialVersionUID = 1L;
    private String name;
    private int damage;
    private int duration;

    public Character(String name, int damage, int duration){
        this.name = name;
        this.damage = damage;
        this.duration = duration;
    }

    public String getName(){
        return name;
    }

    public int getDamage(){
        return damage;
    }

    public int getDuration(){
        return duration;
    }

    public abstract void shoot(Ball ball, int direction); //Cada país implementa este método a su manera.

    //Aca aplicamos el patron de diseño Factory Method.
    public abstract Effect createEffect(int direction); //Cada subclase decide que objeto crear y Match solo recibe un efecto pero sin saber cual es.
}
