package domain;

public class Cameroon extends Character{
    public Cameroon(){
        super("Camerún", 60, 180);
    }

    @Override
    public void shoot(Ball ball, int direction){
        ball.push(direction * 28, -2); //Un poco menos potente que Korea
    }

    @Override // La direccion solo se tiene en cuenta para el poder que aplica Korea
    public Effect createEffect(int direction){
        return new Electrocuted();
    }
}
