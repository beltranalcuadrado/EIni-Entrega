package domain;

public class Korea extends Character{
    public Korea(){
        super("Corea del Sur", 40, 90);
    }

    @Override
    public void shoot(Ball ball, int direction){
        ball.push(direction * 35, -2); //recto y muy rapido
    }

    @Override
    public Effect createEffect(int direction){
        return new Pushed(direction);
    }
}
