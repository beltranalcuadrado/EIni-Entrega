package domain;

public class Expert implements MachineProfile{
    
    private MachineProfile attack = new Offensive();
    private MachineProfile defense = new Defensive();

    @Override 
    public void play(Match match){
        if (match.getGoals2() > match.getGoals1()){ //Si la maquina va ganando, juega como la Defensive
            defense.play(match);
        }
        else{
            attack.play(match); //Si va perdiendo o empatando, juega como la Offensive
        }
    }
}
