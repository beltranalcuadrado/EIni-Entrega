package domain;

public class USA extends Character{
    public USA(){
        super("Estados Unidos", 30, 150);
    }

    @Override
    public void shoot(Ball ball, int direction){
        ball.push(direction * 25, -2); 
    }

    @Override
    public Effect createEffect(int direction){
        return new Confused();
    }
}
