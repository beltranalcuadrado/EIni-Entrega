package domain;

public class Pushed implements Effect {
    private int direction;

    public Pushed(int direction){
        this.direction = direction;
    }

    public void start(Player victim){
        victim.launch(direction * 25, 0); //Lanza al rival de forma horizontal
    }

    public boolean canMove(){
        return false;
    }

    public boolean canJump(){
        return false;
    }

    public boolean canKick(){
        return false;
    }

    public double speedFactor(){
        return 0;
    }

    public String getName(){
        return "Empujado";
    }
}
