package domain;

public class Electrocuted implements Effect {
    
    public void start(Player victim){
        return;
    }

    public boolean canMove(){
        return true;
    }

    public boolean canJump(){
        return false;
    }

    public boolean canKick(){
        return true;
    }

    public double speedFactor(){
        return 0.5;
    }

    public String getName(){
        return "Electrocutado";
    }
}
