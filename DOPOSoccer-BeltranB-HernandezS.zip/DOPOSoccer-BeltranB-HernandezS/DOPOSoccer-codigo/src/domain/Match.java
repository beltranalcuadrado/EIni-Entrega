package domain;
public class Match implements java.io.Serializable {
    private static final long serialVersionUID = 1L;
    private Player player1;
    private Player player2;
    private Ball ball;
    private boolean finished;
    private int goals1;
    private int goals2;
    private static final int PLAYER1_START_X = 200;
    private static final int PLAYER2_START_X = 800;
    private static final int TOUCH_FORCE = 8;
    private static final int TOUCH_LIFT = 10;

    private static final int KICK_RANGE = 70; //más que la distancias de contacto
    private static final int KICK_FORCE = 20;
    private static final int KICK_LIFT = 12;

    private static final int PITCH_WIDTH = 1000;
    private static final int GROUND = 450;
    private static final int GOAL_WIDTH = 50;
    private static final int GOAL_HEIGHT = 150;

    public static final String TIME = "TIME";
    public static final String GOALS = "GOALS";

    private static final int KICK_DAMAGE = 10;

    private static final int FPS = 60;

    private static final int GOAL_POWER_BONUS = Player.POWER_BAR_FULL / 4;

    private String matchType;
    private int limit;
    private int frames = 0;
    private boolean paused;

    private Player powerShooter;
    private int powerDirection;

    private MachineProfile machine;


    public Match(String matchType, int limit) throws POOBSoccerException{
        this(matchType, limit, new Korea(), new Cameroon());
    }

    public Match(String matchType, int limit, Character character1, Character character2) throws POOBSoccerException{
        player1 = new Player(PLAYER1_START_X, character1);
        player2 = new Player(PLAYER2_START_X, character2);
        ball = new Ball();
        goals1 = 0;
        goals2 = 0;
        finished = false;
        paused = false;
        if (!TIME.equals(matchType) && !GOALS.equals(matchType)){
            throw new POOBSoccerException(POOBSoccerException.INVALID_MATCH_TYPE);
        }
        this.matchType = matchType;

        if (limit <= 0){
            throw new POOBSoccerException(POOBSoccerException.INVALID_LIMIT);
        }
        this.limit = limit;
    }

    public void update(){
        if (!finished && !paused){
            if (machine != null){
                machine.play(this);
            }

            player1.update();
            player2.update();
            ball.update();
            checkPowerHit();
            checkCollision(player1);
            checkCollision(player2);
            checkGoal();
            frames++;
            checkEnd();

        }
    }

    public Player getPlayer1(){
        return player1;
    }

    public Player getPlayer2(){
        return player2;
    }

    public Ball getBall(){
        return ball;
    }

    public int getGoals1(){
        return goals1;
    }

    public int getGoals2(){
        return goals2;
    }

    public boolean isFinished(){
        return finished;
    }

    private boolean isNear(Player player, int range){
        int xPlayer = player.getX();
        int yPlayer = player.getY();

        int centerPlayerX = xPlayer;
        int centerPlayerY = (yPlayer - (Player.SIZE / 2));

        int xBall = ball.getX();
        int yBall = ball.getY();

        int centerBallX = xBall; //Tomamos a x como el centro
        int centerBallY = (yBall - (Ball.SIZE / 2)); //En y el centro esta subiendo la mitad del tamaño del balon
        
        if (Math.abs(centerPlayerX - centerBallX) < range && Math.abs(centerPlayerY - centerBallY) < range){
            return true;
        }
        else{
            return false;
        }

    }

    private void checkCollision(Player player){
        int distanceMin = (Player.SIZE / 2) + (Ball.SIZE / 2);
        if (isNear(player, distanceMin)){
            int velX = player.getVelocityX();
            int direction;
            int xBall = ball.getX();
            int xPlayer = player.getX();
            
            if (xBall > xPlayer){
                direction = 1; 
            }
            else{
                direction = -1;
            }

            if (player.hasAura()){
                player.getCharacter().shoot(ball, direction); //cada personaje dispara a su manera (si tiene aura)
                player.loseAura();
                powerShooter = player;
                powerDirection = direction;
            }
            else{
                ball.push(direction * TOUCH_FORCE + velX, -TOUCH_LIFT); //8 es la fuerza a la que sale el balon en la direccion que corresponda (8 por ahora es numero de prueba)
            }
        }
    }

    public void kick(int playerNumber){
        int direction;
        if (playerNumber == 1){
            if (!player1.canKick()){
                return; //Si esta aturdido o se le aplico algun poder que no lo deje patear entonces no puede patear
            }
            direction = 1;
            if(isNear(player1, KICK_RANGE)){
                ball.push(direction * KICK_FORCE, -KICK_LIFT);
            }
            if (playersNear(KICK_RANGE)){
                player2.takeDamage((int)(KICK_DAMAGE * player1.getKickMultiplier()));
            }
        }
        else if (playerNumber == 2){
            direction = -1;
            if (!player2.canKick()){
                return; //Si esta aturdido o se le aplico algun poder que no lo deje patear entonces no puede patear
            }
            if(isNear(player2, KICK_RANGE)){
                ball.push(direction * KICK_FORCE, -KICK_LIFT);
            }
            if (playersNear(KICK_RANGE)){
                player1.takeDamage((int)(KICK_DAMAGE * player2.getKickMultiplier()));
            }
        }
    }

    private void resetPositions(){
        ball.reset();
        player1.resetPlayer(PLAYER1_START_X);
        player2.resetPlayer(PLAYER2_START_X);
    }

    private void checkGoal(){
        int y = ball.getY();
        // Validar gol en el arco del jugador 1 (el de la izquierda)
        if (y - Ball.SIZE > GROUND - GOAL_HEIGHT){ //Si el balon está mas abajo del travesaño 
            int x = ball.getX();
            if (x < GOAL_WIDTH){ // Si el balon esta dentro del arco en x
                goals2++; //gol para el jugador 2
                player1.addPower(GOAL_POWER_BONUS);
                powerShooter = null;
                resetPositions();
            }

            //Mismo caso pero para el arco del jugador 2
            else if (x > PITCH_WIDTH - GOAL_WIDTH){
                goals1++;
                player2.addPower(GOAL_POWER_BONUS);
                powerShooter = null;
                resetPositions();
            }
        } 
    }
    public int getRemainingTime(){
        int timeRemaining;
        if (TIME.equals(matchType)){
            int totalSeconds = limit * 60; //Acá limit funciona como limite de tiempo
            int secondsElapsed = frames / FPS;

            timeRemaining = totalSeconds - secondsElapsed;
            if (timeRemaining < 0){
                timeRemaining = 0;
            }
        }
        else{
            timeRemaining = -1; //Se pone un valor negativo porque en el modo GOALS no se necesita tiempo
        }

        return timeRemaining;
    }

    private void checkEnd(){
        if (GOALS.equals(matchType)){
            if (goals1 >= limit || goals2 >= limit){ //Aca limit funciona como limite de goles
                finished = true;
            }
        }
        else{
            if (getRemainingTime() == 0 && goals1 != goals2){
                finished = true;
            }
        }

    }

    public Player getWinner(){
        Player winner = null;
        if(finished){
            if (goals1 > goals2){
                winner = player1;
            }
            else if (goals2 > goals1){
                winner = player2;
            }
        }
        return winner;
    }

    public void pause(){
        paused = true;
    }

    public void resume(){
        paused = false;
    }

    public boolean isPaused(){
        return paused;
    }

    public void end(){
        finished = true;
    }

    private boolean playersNear(int range){
        int xPlayer1 = player1.getX();
        int yPlayer1 = player1.getY();
        int xPlayer2= player2.getX();
        int yPlayer2 = player2.getY();

        int centerPlayerX1 = xPlayer1;
        int centerPlayerY1 = (yPlayer1 - (Player.SIZE / 2));
        int centerPlayerX2 = xPlayer2;
        int centerPlayerY2 = (yPlayer2 - (Player.SIZE / 2));

       
        if (Math.abs(centerPlayerX1 - centerPlayerX2) < range && Math.abs(centerPlayerY1 - centerPlayerY2) < range){
            return true;
        }
        else{
            return false;
        }
    }

    public void activatePower(int playerNumber){
        if (playerNumber == 1){
            player1.activatePower();
        }
        else if (playerNumber == 2){
            player2.activatePower();
        }
    }

    private void checkPowerHit(){
        if (powerShooter == null){
            return;
        }

        if (ball.getVelocityX() == 0){
            powerShooter = null; //Cuando el balon se queda quieto quiere decir que el tiro perdio fuerza y ya termina el efecto
            return;
        }

        Player rival; //Para saber quien es el afectado por el poder
        if (powerShooter == player1){
            rival = player2;
        }
        else{
            rival = player1;
        }

        int distanceMin = (Player.SIZE / 2) + (Ball.SIZE / 2);
        if (isNear(rival, distanceMin)){
            Character character = powerShooter.getCharacter();
            int dano = (int)(character.getDamage() * powerShooter.getKickMultiplier());
            rival.takeDamage(dano);
            rival.applyEffect(character.createEffect(powerDirection), character.getDuration());
            powerShooter = null; //Aca el tiro ya se uso entonces ponemos esta variable en null para luego volver a utilizarla
        }
    }

    public void setMachine(MachineProfile machine){
        this.machine = machine;
    }

    public boolean hasMachine(){
        if (machine != null){
            return true;
        }
        else{
            return false;
        }
    }
}
