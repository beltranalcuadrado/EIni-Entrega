package domain;

public class Defensive implements MachineProfile{
    
    private static final int HOME_X = 870;
    private int kickCooldown;

    @Override 
    public void play(Match match){
        int target;
        if (kickCooldown > 0){
            kickCooldown--;
        }

        Player machine = match.getPlayer2();
        Ball ball = match.getBall();

        if (ball.getX() > 500){ //Si la pelota esta en la mitad del juagdor 2 entonces el objetivo es la pelota
            target = ball.getX();
        }
        else{
            target = HOME_X; //Si no, el objetivo es mantenerse en una posicion cerca al arco.
        }

        //Logica similar de la clase Offensive pero ahora con target
        if (target < machine.getX() - 10){
            machine.moveLeft();
        }

        else if (target > machine.getX() + 10){
            machine.moveRight();
        }

        else {
            machine.stop();
        }

        if (Math.abs(ball.getX() - machine.getX()) < 50 && ball.getY() < machine.getY() - Player.SIZE){
            machine.jump();
        }

        if (Math.abs(ball.getX() - machine.getX()) < 50 && kickCooldown == 0){
            match.kick(2);
            kickCooldown = 30;
        }

        if (machine.getPowerBar() == Player.POWER_BAR_FULL && ball.getX() > 500){ //Activa el poder si el balon esta de su lado y la barra de poder esta llena
            match.activatePower(2);
        }
    }
}
