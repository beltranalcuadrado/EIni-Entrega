package domain;
import java.io.Serializable;

public interface Effect extends Serializable {
    void start(Player victim);
    boolean canMove();
    boolean canJump();
    boolean canKick();
    double speedFactor();
    String getName();
}
