package domain;
import java.io.*;

public class HeadSoccer implements java.io.Serializable {
    private static final long serialVersionUID = 1L;
    private Match match;

    public HeadSoccer(String matchType, int limit, String character1, String character2) throws POOBSoccerException{
        match = new Match(matchType, limit, createCharacter(character1), createCharacter(character2));
    }

    private Player getPlayer(int player){
        if (player == 1){
            return match.getPlayer1();
        }
        else{
            return match.getPlayer2();
        }
    }
    
    //Controles
    public void moveLeft(int player){
        getPlayer(player).moveLeft();
    }

    public void moveRight(int player){
        getPlayer(player).moveRight();
    }

    public void stop    (int player){
        getPlayer(player).stop();
    }

    public void jump(int player){
        getPlayer(player).jump();
    }

    public void kick(int player){
        match.kick(player);
    }

    //Ciclo
    public void update(){
        match.update();
    }

    public void pause(){
        match.pause();
    }

    public void resume(){
        match.resume();
    }

    public boolean isPaused(){
        return match.isPaused();
    }
    
    public void end(){
        match.end();
    }

    //Para dibujar
    public int getPlayerX(int player){
        return  getPlayer(player).getX();
    }

    public int getPlayerY(int player){
        return getPlayer(player).getY();
    }

    public int getBallX(){
        return match.getBall().getX();
    }

    public int getBallY(){
        return match.getBall().getY();
    }

    public int getPlayerSize(){
        return Player.SIZE;
    }

    public int getBallSize(){
        return Ball.SIZE;
    }

    public int getPitchWidth(){
        return 1000; //anchjo de la cancha
    }

    public int getPitchHeight(){
        return 500; //altura de la cancha
    }

    //Estado
    public int getGoals(int player){
        if (player == 1){
            return match.getGoals1();
        }
        else{
            return match.getGoals2();
        }
    }

    public int getRemainingTime(){
        return match.getRemainingTime();
    }

    public boolean isFinished(){
        return match.isFinished();
    }

    public int getWinner(){
        Player win = match.getWinner();
        if (win == match.getPlayer1()){
            return 1;
        }
        else if (win == match.getPlayer2()){
            return 2;
        }
        else{
            return 0;
        }
        
    }
    //Mostrar vida en pantalla

    public int getLife(int player){
        return getPlayer(player).getLife();
    }

    public int getMaxLife(int player){
        return getPlayer(player).getMaxLife();
    }

    public boolean isStunned(int player){
        return getPlayer(player).isStunned();
    }

    //Poder y aura
    public void activatePower(int player){
        getPlayer(player).activatePower();
    }

    public int getPowerBar(int player){
        return getPlayer(player).getPowerBar();
    }

    public boolean hasAura(int player){
        return getPlayer(player).hasAura();
    }

    public int getPowerBarFull(){
        return Player.POWER_BAR_FULL; //Para que la GUI pueda calcular el ancho de la barra
    }

    private Character createCharacter(String name) throws POOBSoccerException{
        if ("Corea del Sur".equals(name)){
            return new Korea();
        }

        else if ("Camerún".equals(name)){
            return new Cameroon();
        }

        else if ("Nigeria".equals(name)){
            return new Nigeria();
        }

        else if ("Estados Unidos".equals(name)){
            return new USA();
        }

        else{
            throw new POOBSoccerException(POOBSoccerException.INVALID_CHARACTER);
        }
    }

    public String getCharacterName(int player){ //Obtener el nombre del jugador
        return getPlayer(player).getCharacter().getName();
    }

    public String getEffectName(int player){
        return getPlayer(player).getEffectName();
    }

    public void setMachine(String profile) throws POOBSoccerException{
        match.setMachine(createProfile(profile));
    }

    private MachineProfile createProfile(String name) throws POOBSoccerException{
        if ("Torpe".equals(name)){
            return new Clumsy();
        }
        else if ("Ofensiva".equals(name)){
            return new Offensive();
        }

        else if ("Defensiva".equals(name)){
            return new Defensive();
        }

        else if ("Experta".equals(name)){
            return new Expert();
        }

        else{
            throw new POOBSoccerException(POOBSoccerException.INVALID_PROFILE);
        }
    }

    public void save(File file) throws POOBSoccerException {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(file))) {
            out.writeObject(this);
        } catch (IOException e) {
            Log.record(e);
            throw new POOBSoccerException(POOBSoccerException.SAVE_ERROR);
        }
    }

    public static HeadSoccer open(File file) throws POOBSoccerException {
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(file))) {
            return (HeadSoccer) in.readObject();
        } catch (IOException | ClassNotFoundException | ClassCastException e) {
            Log.record(e);
            throw new POOBSoccerException(POOBSoccerException.OPEN_ERROR);
        }
    }

    public boolean hasMachine(){
        if (match.hasMachine()){
            return true;
        }
        else{
            return false;
        }
    }
}
