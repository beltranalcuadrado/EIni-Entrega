package domain;

public class Confused implements Effect{
    
    public void start(Player victim){
        return;
    }

    public boolean canMove(){
        return true;
    }

    public boolean canJump(){
        return true;
    }

    public boolean canKick(){
        return true;
    }

    public double speedFactor(){
        return 1.0;
    }

    public String getName(){
        return "Confundido";
    }
}

