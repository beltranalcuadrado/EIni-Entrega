package domain;

public class Unconscious implements Effect{
    
    public void start(Player victim){
        victim.launch(0, -20); //Lanza al jugador hacia arriba
    }

    public boolean canMove(){
        return false;
    }

    public boolean canJump(){
        return false;
    }

    public boolean canKick(){
        return false;
    }

    public double speedFactor(){
        return 0;
    }

    public String getName(){
        return "Inconsciente";
    }
}
