package domain;

public class Offensive implements MachineProfile{
    
    private int kickCooldown;

    @Override 
    public void play(Match match){
        if (kickCooldown > 0){
            kickCooldown--;
        }

        Player machine = match.getPlayer2();
        Ball ball = match.getBall();

        if (ball.getX() < machine.getX() - 10){
            machine.moveLeft();
        }

        else if (ball.getX() > machine.getX() + 10){
            machine.moveRight();
        }

        else {
            machine.stop();
        }

        if (Math.abs(ball.getX() - machine.getX()) < 50 && ball.getY() < machine.getY() - Player.SIZE){
            machine.jump();
        }

        if (Math.abs(ball.getX() - machine.getX()) < 50 && kickCooldown == 0){
            match.kick(2);
            kickCooldown = 30;
        }

        if (machine.getPowerBar() == Player.POWER_BAR_FULL){
            match.activatePower(2);
        }
    }
}
