package domain;

public class Nigeria extends Character{
    public Nigeria(){
        super("Nigeria", 40, 180);
    }

    @Override
    public void shoot(Ball ball, int direction){
        ball.push(direction * 25, 0); //Para que salga recto y a ras de piso
    }

    @Override
    public Effect createEffect(int direction){
        return new Unconscious();
    }
}
