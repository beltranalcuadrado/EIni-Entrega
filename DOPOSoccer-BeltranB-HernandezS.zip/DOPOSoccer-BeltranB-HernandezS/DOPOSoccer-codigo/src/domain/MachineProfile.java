package domain;
import java.io.Serializable;

public interface MachineProfile extends Serializable{ //A partir de aca se aplica el patron Strategy
    void play(Match match); //Match delega la decisión de la máquina a un MachineProfile, y cada perfil es una estrategia intercambiable.
}
