package domain;
import java.io.*;
public class Player implements java.io.Serializable{
    private static final long serialVersionUID = 1L;
    private static final int GRAVITY = 1;
    private static final int SPEED = 10;
    private static final int JUMP_FORCE = 18;
    private static final int GROUND = 450;
    private static final int PITCH_WIDTH = 1000;
    public static final int SIZE = 60;

    public static final int BASE_LIFE = 100;
    private static final int STUN_FRAMES = 180;

    public static final int POWER_BAR_FULL = 600;

    private int x;
    private int y;
    private int velocityX;
    private int velocityY;
    private boolean onGround;

    private int kick = 1;
    private int survival = 1;
    private int life;
    private int maxLife;
    private int stunFrames;

    private int powerBar;
    private boolean hasAura;

    private Character character;

    private Effect effect;
    private int effectFrames;

    public Player(int x, Character character){
        resetPlayer(x);
        maxLife = (int)(BASE_LIFE * (1 + 0.10 * (survival - 1)));
        life = maxLife;
        stunFrames = 0;
        powerBar = 0;
        hasAura = false;
        this.character = character;
        effect = null;
    }

    public Player(int x){ //Constructor para que los test sigan funcionando.
        this(x, new Korea());
    }

    public void moveLeft(){
        if (isStunned()){
            return;
        }

        //Restricciones de movimiento si al jugador se le aplico efecto
        if (effectFrames > 0){
            if (!effect.canMove()){
                return; //Si el jugador tiene efecto aplicado y no se puede mover, entonces no hay nada que hacer aca
            }
            else{
                velocityX = (int)(-SPEED * effect.speedFactor());
            }
        }
        else{
            velocityX = -SPEED;
        }
    }

    public void moveRight(){
        if (isStunned()){
            return;
        }

        //Restricciones de movimiento si al jugador se le aplico efecto
        if (effectFrames > 0){
            if (!effect.canMove()){
                return; //Si el jugador tiene efecto aplicado y no se puede mover, entonces no hay nada que hacer aca
            }
            else{
                velocityX = (int)(SPEED * effect.speedFactor());
            }
        }
        else{
            velocityX = SPEED;
        }
    }

    public void stop(){
        if (effectFrames > 0 && !effect.canMove()){ //En caso de que el jugador no este tocando ninguna tecla y esta siendo afectado por el poder
            return; //entonces hacemos este return para que el jugador no se detenga de golpe sino que deslice hasta su arco durante 1.5 s
        }

        else{
            velocityX = 0; 
        }
    }

    public void jump(){
        if (isStunned()){
            return;
        }

        if (effectFrames > 0 && !effect.canJump()){ //Si al jugador se le aplico un poder y no puede saltar entonces hacemos return
            return;
        }

        if (onGround){
            velocityY = -JUMP_FORCE; //Negativo hacia arriba, positivo hacia abajo
            onGround = false;
        }
    }

    public void update(){
        //Aturdimiento
        if (stunFrames > 0){
            stunFrames--;
            if (stunFrames == 0){
                life = maxLife;
            }
            else{
                velocityX = 0; //Para que no se pueda dezlizar el jugador
            }
        }

        velocityY += GRAVITY;
        x += velocityX;
        y += velocityY;

        if (y >= GROUND){ //Revisar si el jugador esta en el suelo
            y = GROUND;
            onGround = true;
            velocityY = 0;
        }
        else{
            onGround = false;
        }

        //Revisar que el jugador no se salga de las paredes
        if (x < 0){
            x = 0;
        }
        if (x > PITCH_WIDTH){
            x = PITCH_WIDTH;
        }

        //Barra de poder
        addPower(1);

        //Poder aplicado en contra del jugador
        if (effectFrames > 0){
            effectFrames--;
        }
        if (effectFrames == 0){
            effect = null;
        }
    }

    public int getX(){
        return x;
    }

    public int getY(){
        return y;
    }

    public boolean isOnGround(){
        return onGround;
    }

    public int getVelocityX(){
        return velocityX;
    }

    public void resetPlayer(int startX){
        x = startX;
        y = GROUND;
        velocityX = 0;
        velocityY = 0;
        onGround = true;
    }

    public double getKickMultiplier(){
        return 1 + 0.10 * (kick - 1);
    }

    public void takeDamage(int damage){
        if (isStunned()){
            return;
        }
        life -= damage; //Resta el daño a life
        if (life <= 0){
            life = 0;
            stunFrames = STUN_FRAMES;
        }
    }

    public boolean isStunned(){
        if (stunFrames > 0){
            return true;
        }
        else{
            return false;
        }
    }

    public int getLife(){
        return life;
    }

    public int getMaxLife(){
        return maxLife;
    }

    public void addPower(int amount){
        powerBar += amount;

        if (powerBar >= POWER_BAR_FULL){
            powerBar = POWER_BAR_FULL;
        }
    }

    public void activatePower(){
        if (powerBar == POWER_BAR_FULL && !hasAura && !isStunned()){
            hasAura = true;
            powerBar = 0;
        }
    }

    public void loseAura(){
        hasAura = false;
    }

    public boolean hasAura(){
        return hasAura;
    }

    public int getPowerBar(){
        return powerBar;
    }

    public Character getCharacter(){
        return character;
    }

    public void launch(int velX, int velY){
        velocityX = velX;
        velocityY = velY;
    }

    public boolean canKick(){ //Si el jugador esta aturdido o no puede patear por el poder que se le aplico entonces no puede patear
        if (isStunned() || (effectFrames > 0 && !effect.canKick())){
            return false;
        }
        else{
            return true;
        }
    }

    public void applyEffect(Effect newEffect, int duration){
        effect = newEffect;
        effectFrames = duration;
        newEffect.start(this);
    }

    public String getEffectName(){
        if (effectFrames == 0 || effect == null){
            return "";
        }
        else{
            return effect.getName();
        }
    }
}