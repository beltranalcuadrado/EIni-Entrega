package domain;

public class Clumsy implements MachineProfile{
    private int action;
    private int remainingFrames;

    @Override
    public void play(Match match){
        Player machine = match.getPlayer2(); //El jugador 2 sera la máquina
        if (remainingFrames == 0){
            action = (int)(Math.random() * 5); //Escoger una opcion al azar
            remainingFrames = 30; //La accion dura medio segundo
            if (action == 3){
                machine.jump();
            }
            else if (action == 4){
                match.kick(2);
            }
            
        }
        else{
            remainingFrames--;
        }
        
        switch (action){
            case 0:
                machine.moveLeft();
                break;
            case 1:
                machine.moveRight();
                break;
            case 2:
                machine.stop();
                break;
            case 3:
                machine.stop();
                break;
            case 4:
                machine.stop();
                break;
        }
    }
}
